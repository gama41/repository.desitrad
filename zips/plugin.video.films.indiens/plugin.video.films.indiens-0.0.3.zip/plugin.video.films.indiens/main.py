import sys
from urllib import urlencode
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import xbmc
import json
from lib.HTMLParser import HTMLParser

_url = sys.argv[0]
_handle = int(sys.argv[1])
message = {"Message": "d97a47fcb6dd3092e41d316e08a2a4cc"}


from urllib import urlopen
import requests as rq
languages = ['Tamil', 'Telugu', 'Malayalam', 'Hindi', 'Kannada', 'all']
movies = []
plugin_domain = "http://desi-trad.raidghost.com/kodi/public/api/"
for l in languages:
    url_movies = rq.get(plugin_domain+"films/"+l, headers=message)
    movies.append(json.loads(url_movies.text))
url_songs = rq.get(plugin_domain+"songs", headers=message)
bandes_annonces = []
for x in movies[5]:
    if x['ba_yt_link'] is not None and x['ba_amara_link'] is not None:
        bandes_annonces.append({'titre': x['titre'], 'amara': x['ba_amara_link'], 'yt':x['ba_yt_link'], 'date_publication': x['date_publication']})
    elif x['ba_yt_link'] is not None :
        bandes_annonces.append({'titre': x['titre'], 'yt':x['ba_yt_link'], 'date_publication': x['date_publication']})
songs = json.loads(url_songs.text)
VIDEOS = {"Tamil": movies[0], "Telugu": movies[1], "Malayalam": movies[2], "Hindi": movies[3], "Kannada": movies[4], "all": movies[5], "Songs": songs, "ba": bandes_annonces }
domain = "http://desi-trad.alwaysdata.net/srt/"

def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :type kwargs: dict
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: types.GeneratorType
    """
    return VIDEOS.iterkeys()


def get_videos(category):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of video streams in the given category from some site or server.

    .. note:: Consider using `generators functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :param category: Category name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    xbmcplugin.setPluginCategory(_handle, 'Films Indiens en VOSTFR')
    xbmcplugin.setContent(_handle, 'movies')
    categories = get_categories()
    for category in categories:
        if category == 'Songs' :
            list_item = xbmcgui.ListItem(label='Chansons en VOSTFR')
            list_item.setArt({'poster': 'http://desi-trad.alwaysdata.net/kodi/1.png'})
        elif category == 'ba' or languages.index(category) > -1:
            libelle = 'Films '+category+' en VOSTFR'
            if category == 'ba' :
                libelle = 'Bandes-annonces en VOSTFR'
            elif category == 'all' :
                libelle = 'Tous les films en VOSTFR'             
            list_item = xbmcgui.ListItem(label=libelle)
            list_item.setArt({'poster': 'http://desi-trad.alwaysdata.net/kodi/'+category+'.png'})
            list_item.setInfo('video', {'title': category,
                                        'genre': category,
                                        'mediatype': 'video'})
        url = get_url(action='listing', category=category)
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    xbmcplugin.setPluginCategory(_handle, category)
    xbmcplugin.setContent(_handle, 'movies')
    if category == "Songs" :
        xbmcplugin.setContent(_handle, 'musicvideos')
        songs = get_videos(category)
        for song in songs:
            list_item = xbmcgui.ListItem(label=song['titre'])
            list_item.setProperty('IsPlayable', 'true')
            list_item.setInfo('video', {'title': song['titre'],
                                        'mediatype': 'movie'})
            list_item.setArt({'thumb': "https://img.youtube.com/vi/"+song['yt']+"/hqdefault.jpg"})
            url = "plugin://plugin.video.youtube/play/?video_id="+song['yt']
            is_folder = False
            url = get_url(action='play', video=url)
            subtitles = domain+'chansons/'+song['tag']+'.srt'
            list_item.setSubtitles([subtitles])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
    elif category == "ba":
        xbmcplugin.setContent(_handle, 'musicvideos')
        ba = get_videos(category)
        for a_ba in ba:
            list_item = xbmcgui.ListItem(label=a_ba['titre'])
            list_item.setProperty('IsPlayable', 'true')
            list_item.setInfo('video', {'title': a_ba['titre'],
                              'dateadded': a_ba['date_publication']+' 23:16:04'})
            list_item.setArt({'thumb': "https://img.youtube.com/vi/"+a_ba['yt']+"/hqdefault.jpg"})
            url = "plugin://plugin.video.youtube/play/?video_id="+a_ba['yt']
            is_folder = False
            url = get_url(action='play', video=url)
            if a_ba.get('amara', 'Undefined') != 'Undefined' : 
                subtitles = 'https://amara.org/api/videos/'+a_ba['amara']+'/languages/fr/subtitles/?format=srt'
                list_item.setSubtitles([subtitles])
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_DATEADDED)
    else :
        videos = get_videos(category)
        for idx, video in enumerate(videos):
            list_item = xbmcgui.ListItem(label=video['titre'])
            list_item.setInfo('video', {'title': video['titre'],
                                        'mediatype': 'movie', 
                                        'year': int(video['sortie']), 
                                        'director': video['metteur_en_scene'], 
                                        'plot': HTMLParser.HTMLParser().unescape(video['description']),
                                        'writer': video['scenariste'], 
                                        'dateadded': video['date_publication']+' 23:16:04',
                                        'cast': video['cast']})										
            if video['ba_yt_link'] is not None:
               list_item.setInfo('video', {'trailer': 'plugin://plugin.video.youtube/play/?video_id='+video['ba_yt_link']})
            list_item.setArt({'poster': video['poster'], 'thumb': video['wallpaper']})
            title_no_space = video['titre'].replace(" ", "%20")
            if (video['statut'] == 1 or video['statut'] == 2) and video['partie'] == 0 and video['yt_link'] is not None:
                list_item.setProperty('IsPlayable', 'true')
                subtitles = domain+'films/'+video['langue'].lower()+'/'+title_no_space+'.srt'
                list_item.setSubtitles([subtitles])
                url = "plugin://plugin.video.youtube/play/?video_id="+video['yt_link']
                is_folder = False
                url = get_url(action='play', video=url)
            elif video['statut'] == 1 and video['partie'] == 1 :
                list_item.setProperty('IsPlayable', 'false')
                idx = videos.index(video)
                url = get_url(action='playlist', title=video['titre'], index=str(idx), language=video['langue'], type=category )
                is_folder = True
            else:
                url = video['url']
                is_folder = False
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.endOfDirectory(_handle)

def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def playlist(title, index, language, type):
    videos = get_videos(type)
    xbmcplugin.setPluginCategory(_handle, 'Part')
    xbmcplugin.setContent(_handle, 'movies')
    for partie in videos[int(int(index))]['parties']:
        part_name = 'Partie ' +str(partie['numPartie'])
        list_item_pl = xbmcgui.ListItem(label=part_name)
        list_item_pl.setInfo('video', {'title': part_name,
                            'mediatype': 'video'})
        url_pl = "plugin://plugin.video.youtube/play/?video_id="+partie['yt_link']            
        list_item_pl.setProperty('IsPlayable', 'true')
        list_item_pl.setArt({'thumb': "https://img.youtube.com/vi/"+partie['yt_link']+"/hqdefault.jpg"})
        subtitles = domain+'films/'+language.lower()+'/'+title.replace(" ", "%20")+'/part'+str(partie['numPartie'])+'.srt'
        list_item_pl.setSubtitles([subtitles])
        url = get_url(action='play', video=url_pl)
        xbmcplugin.addDirectoryItem(_handle, url, list_item_pl, False)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)

def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'listing' and params['category'] != "Songs":
            list_videos(params['category'])
        elif params['action'] == 'listing' and params['category'] == "Songs":
            list_videos(params['category'])
        elif params['action'] == 'play':
            play_video(params['video'])
        elif params['action'] == 'playlist':
            playlist(params['title'], params['index'], params['language'], params['type'])        
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_categories()


if __name__ == '__main__':
    router(sys.argv[2][1:])
